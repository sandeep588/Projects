/**
 * @description       : 
 * @author            : Sandeep Kumar Gond
 * @group             : 
 * @last modified on  : 07-19-2023
 * @last modified by  : Sandeep Kumar
**/
import { api, LightningElement, track } from 'lwc';
import saveFile from '@salesforce/apex/VFC149_ConductInspection_lwc.saveFile';
import { deleteRecord } from 'lightning/uiRecordApi';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

import lbl_File_size_is_too_long from '@salesforce/label/c.File_size_is_too_long';
import lbl_file_supported_format from '@salesforce/label/c.file_supported_format';
import lbl_Uploading_dot from '@salesforce/label/c.Uploading_dot';
import lbl_Delete from '@salesforce/label/c.Delete';
import lbl_View from '@salesforce/label/c.View';
import lbl_Name from '@salesforce/label/c.Name';
import lbl_Type from '@salesforce/label/c.Type';
import lbl_deleteconfirmation from '@salesforce/label/c.deleteconfirmation';
import lbl_Cancel_E from '@salesforce/label/c.Cancel_E';
import lbl_uploaded_successfully from '@salesforce/label/c.dash_uploaded_successfully';
import lbl_file_uploaded_successfully from '@salesforce/label/c.file_uploaded_successfully';
import lbl_Success from '@salesforce/label/c.Success';
import lbl_Error from '@salesforce/label/c.Error';
import lbl_Error_uploading_file from '@salesforce/label/c.Error_uploading_file';

import { createRecord } from 'lightning/uiRecordApi';
import ContentVersion from '@salesforce/schema/ContentVersion';
import Title from '@salesforce/schema/ContentVersion.Title';
import VersionData from '@salesforce/schema/ContentVersion.VersionData';
import PathOnClient from '@salesforce/schema/ContentVersion.PathOnClient';
import InspectionQuestion from '@salesforce/schema/ContentVersion.InspectionQuestion__c';
import Site from '@salesforce/schema/ContentVersion.Site__c';
import Origin from '@salesforce/schema/ContentVersion.Origin__c';
import InspectionId from '@salesforce/schema/ContentVersion.InspectionId__c';
export default class Lc211_ConductInspectionMedia extends NavigationMixin(LightningElement) {
    label = {
        lbl_file_supported_format, lbl_Uploading_dot, lbl_Delete, lbl_View, lbl_Name, lbl_Type, lbl_deleteconfirmation, lbl_Cancel_E,

    };
    @api status;
    @api accountid;
    @api roominspectionid;
    @api questionid;
    @api files;
    filesUploaded = [];
    file;
    fileContents;
    fileReader;
    content;
    MAX_FILE_SIZE = 2.6 * 1024 * 1024;
    @track fileName = '';
    connectedcallback() {
        console.log('status', this.status);
    }

    handleFilesChange(event) {
        if (event.target.files.length > 0) {
            for (var i = 0; i < event.target.files.length; i++) {
                this.filesUploaded = event.target.files[i];
                this.fileName = event.target.files[i].name;
            }
        }
        this.uploadHelper();
    }
    showLoadingSpinner = false;
    // uploadHelper() {
    //     this.file = this.filesUploaded;

    //     /* 
    //     Task 39370 (Completed) from ServiceReq 52350
    //     Date: 3 April 2023 modified by Sandeep
    //     Limit removed from image size, now user can uplaod file size of any length

    //     if (this.file.size > this.MAX_FILE_SIZE) {
    //         window.console.log(lbl_File_size_is_too_long);
    //         return ;
    //     }
    //     */
    //     console.log('this.file.size: ', this.file.size);
    //     this.showLoadingSpinner = true;
    //     this.dispatchEvent(new CustomEvent('showloading', { detail: "" }));
    //     // create a FileReader object 
    //     this.fileReader = new FileReader();
    //     // set onload function of FileReader object  
    //     this.fileReader.onloadend = (() => {
    //         this.fileContents = this.fileReader.result;
    //         let base64 = 'base64,';
    //         this.content = this.fileContents.indexOf(base64) + base64.length;
    //         this.fileContents = this.fileContents.substring(this.content);
    //         // call the uploadProcess method 
    //         this.saveToFile();
    //     });

    //     this.fileReader.readAsDataURL(this.file);
    //     console.log('89');
    // }
    uploadHelper() {
        this.file = this.filesUploaded;
        this.showLoadingSpinner = true;
        this.dispatchEvent(new CustomEvent('showloading', { detail: "" }));
        // Check if the file is an image
        if (!this.file.type.startsWith('image/')) {
            console.log('Doc Upload');
            if (this.file.size > this.MAX_FILE_SIZE) {
                window.console.log(lbl_File_size_is_too_long);
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: lbl_File_size_is_too_long,
                        message: '',
                        variant: 'error',
                    }));
                    this.showLoadingSpinner = false;
                return ;
            }
            // Handle the error or display a message that the file is not an image
            this.fileReader = new FileReader();
            // set onload function of FileReader object  
            this.fileReader.onloadend = (() => {
                this.fileContents = this.fileReader.result;
                let base64 = 'base64,';
                this.content = this.fileContents.indexOf(base64) + base64.length;
                this.fileContents = this.fileContents.substring(this.content);
                // call the uploadProcess method 
                this.saveToFile();
            });
        }else{
            // Create a FileReader object
            console.log('Image Upload');
            this.fileReader = new FileReader();

            // Set onload function of FileReader object
            this.fileReader.onloadend = () => {
            this.resizeAndSaveToFile();
            };
        }
        this.fileReader.readAsDataURL(this.file);
    }
    resizeAndSaveToFile() {
        var image = new Image();
        image.onload = () => {
            var canvas = document.createElement('canvas');
            var context = canvas.getContext('2d');
            // Set the desired width and height for the resized image
            var maxWidth = 800;
            var maxHeight = 600;
            var width = image.width;
            var height = image.height;
            // Calculate the new width and height while maintaining the aspect ratio
            if (width > height) {
                if (width > maxWidth) {
                    height *= maxWidth / width;
                    width = maxWidth;
                }
            } else {
                if (height > maxHeight) {
                    width *= maxHeight / height;
                    height = maxHeight;
                }
            }
            // Set the canvas dimensions
            canvas.width = width;
            canvas.height = height;
            // Draw the image on the canvas
            context.drawImage(image, 0, 0, width, height);

            // Get the resized image as a data URL
            var resizedDataUrl = canvas.toDataURL('image/jpeg', 0.8); // Adjust the image quality if needed

            // Encode the resized image to base64
            this.fileContents = resizedDataUrl.replace(/^data:image\/(png|jpeg|jpg);base64,/, '');

            // Now you can use the base64Data for your upload logic
            console.log('Resized image base64 data:', this.fileContents);

            // Continue with the rest of your upload process
            this.saveToFile();
        };

        image.src = this.fileReader.result;
    }

    saveToFile() {
        console.log(93);
        var base64DataTemp =  encodeURIComponent(this.fileContents);
        saveFile({ accountId:this.accountid, roomInspectionId:this.roominspectionid,questionInspectionDoc: this.questionid, strFileName: this.file.name, base64Data: base64DataTemp,fileName:this.fileName})
        .then(result => {
            console.log(96);
            this.fileName = this.fileName + lbl_uploaded_successfully;
            this.UploadFile = lbl_file_uploaded_successfully;
            this.showLoadingSpinner = false;
            this.dispatchEvent( new CustomEvent('stoploading', {detail : ""}));
            // Showing Success message after file insert
            this.dispatchEvent(
                new ShowToastEvent({
                    title: lbl_Success,
                    message: this.file.name + lbl_uploaded_successfully,
                    variant: 'success',
                }),
            );
            this.dispatchEvent( new CustomEvent('fileuploaded', {detail : ""}));
            
      
        })
        .catch(error => {
            // Showing errors if any while inserting the files
            console.log('Lc211_ConductInspectionMedia 123 ',error);
            this.dispatchEvent(
                new ShowToastEvent({
                    title: lbl_Error_uploading_file,
                    message: error.message,
                    variant: 'error',
                }),
            );
        });
        
    }
    originalMessage = '';
    isDialogVisible = false;
    handleDelete(event) {
        if (event.target) {
            if (event.target.name === 'openConfirmation') {
                //it can be set dynamically based on your logic
                this.originalMessage = event.currentTarget.dataset.id;
                this.isDialogVisible = true;
            } else if (event.target.name === 'confirmModal') {
                if (event.detail !== 1) {
                    if (event.detail.status === 'confirm') {
                        //delete content document

                        let contentDocumentId = event.detail.originalMessage;

                        deleteRecord(contentDocumentId)
                            .then(() => {
                                this.dispatchEvent(new CustomEvent('filedelete', { detail: "" }));
                            })
                            .catch(error => {
                                this.dispatchEvent(new CustomEvent('filedeleteerror', { detail: "" }));
                            });

                    }
                }

                //hides the component
                this.isDialogVisible = false;
            }
        }

    }
    filePreview(event) {
        // Naviagation Service to the show preview
        this[NavigationMixin.Navigate]({
            type: 'standard__namedPage',
            attributes: {
                pageName: 'filePreview'
            },
            state: {
                // assigning ContentDocumentId to show the preview of file
                selectedRecordId: event.currentTarget.dataset.id
            }
        })
    }
    closeModal() {
        this.dispatchEvent(new CustomEvent('closemodal', { detail: "" }));
    }
}